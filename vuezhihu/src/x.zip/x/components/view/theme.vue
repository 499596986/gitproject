<template>
	<div class="theme">
		<div class="theme-banner fd-locate">
			<img src="../../assets/images/test.jpg" alt="">
			<div class="theme-banner-content">
				<h2 >了解彼此,测试测试<br>测试测试</h2>
				<p>日常心理学</p>
			</div>
		</div>
		<div class="home-text">
			<div class="home-list">
				<ul>
					<li>
						<p>测试测试测试测试测试</p>
					</li>
					<li>
						<img src="../../assets/images/test.jpg" alt="">
						<p>测试测试测试<br>测试测试</p>
					</li>
					<li>
						<img src="../../assets/images/test.jpg" alt="">
						<p>测试测试测试<br>测试测试</p>
					</li>
				</ul>
			</div>
		</div>
	</div>

</template>
<script>
	
</script>
<style scope>
	.theme-banner .theme-banner-content{
		position:absolute;
		font-size:0.4rem;
		color:#fff;
		top:2rem;
		right:0px;
		padding:0px 0.3rem 0.3rem;
		line-height:0.8rem;
		text-align:right;
	}
	.theme-banner h2{
		padding-bottom:0.3rem;
		margin-bottom:0.1rem;
		position:relative;
	}
	.theme-banner h2:after{
		content:"";
		position:absolute;
		bottom:0px;
		right:0rem;
		width:2rem;
		border:2px solid #ffd300;
	}

	.home-text{

	}

</style>